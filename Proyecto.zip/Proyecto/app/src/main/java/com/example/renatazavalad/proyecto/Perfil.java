package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Perfil extends AppCompatActivity {

    private TextView nombre, cu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil);

        nombre = (TextView)findViewById(R.id.tvNombrelabo);
        cu = (TextView)findViewById(R.id.tvCulabo);

        //Permite que se redirija a esta ventana
        Bundle bCrea1 = this.getIntent().getExtras();
        Bundle bCrea2 = this.getIntent().getExtras();
        //en el bundle get va la sesion
        nombre.setText(""+ bCrea1.get("Nombre"));
    }

    //Este método redirige al menú
    public void regresar4(View v) {
        Intent intent = new Intent(Perfil.this, Menu.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige a la clase modificar
    public void regresarp(View v) {
        Intent intent = new Intent(Perfil.this, Modificar.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }



}
