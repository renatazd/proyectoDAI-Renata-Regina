package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserNameActivity extends AppCompatActivity {

    private EditText user, passwor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_name);

        //Permita que se redirija a esta venatana
        Bundle bundle = this.getIntent().getExtras();
        Bundle bBueno = this.getIntent().getExtras();

        user = (EditText) findViewById(R.id.etUsername);
        passwor = (EditText) findViewById(R.id.etPassword);

    }

    //este método limpia los campos de la vista
    public void limpiar(View v){
        user.setText("");
        passwor.setText("");
    }

    //este metodo valida la sesion del login para poder iniciar sesion si ya se tiene una cuenta existente
    public void validarSesion(View v){
        String pass, username;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null,1);
        SQLiteDatabase bd = admin.getReadableDatabase();
        username = user.getText().toString();
        Cursor fila = bd.rawQuery("select password from usuarios where username = '"+ username+"'",null);
        int contador, passbd;
       contador= Integer.parseInt(passwor.getText().toString());
        if(fila.moveToFirst()){
            passbd = Integer.parseInt(fila.getString(0));
            if(contador == passbd){
                Toast.makeText(this, "Correcto", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(UserNameActivity.this, Menu.class);
                Bundle b = new Bundle();
                b.putString("Nombre", user.getText().toString());
                intent.putExtras(b);
                startActivity(intent);
            }
            else
                Toast.makeText(this, "Password incorrecto", Toast.LENGTH_SHORT).show();


        }
        else
            Toast.makeText(this, "No existe el usuario", Toast.LENGTH_SHORT).show();
    }
}
