package com.example.renatazavalad.proyecto;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Crear extends AppCompatActivity {

    private EditText nom, username, password, cu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crear);

        //Permite que otras ventanas se redirijan a estas
        Bundle bundle = this.getIntent().getExtras();

        nom = (EditText) findViewById(R.id.etNombre);
        username = (EditText) findViewById(R.id.etUserCrea);
        password = (EditText) findViewById(R.id.etPassCrea);
        cu = (EditText) findViewById(R.id.etCU);
    }

    //limpia los campos de la vista
    public void limpiar(View v){
        nom.setText("");
        username.setText("");
        password.setText("");
        cu.setText("");
    }

    //agrega una nueva cuenta de usuario a la base de datos y la tabla usuario
    public void alta(View v){
        String nombre, usern, passw,clave;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        clave = cu.getText().toString();
        nombre = nom.getText().toString();
        usern = username.getText().toString();
        passw = password.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("cu", clave);
        registro.put("nombre", nombre);
        registro.put("username", usern);
        registro.put("password", passw);
        long prueba = bd.insert("usuarios", null, registro);
        limpiar(v);
        //verificamos que si se hayan insertado los datos a la base de datos
        if (prueba>0){
            Toast.makeText(this, "se cargaron los datos del usuario", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Crear.this, UserNameActivity.class);
            Bundle b1 = new Bundle();
            startActivity(intent);
        }else{
            Toast.makeText(this, "No se cargaron los datos del usuario", Toast.LENGTH_LONG).show();
        }

        bd.close();

    }

    //Este método redirige al menú
    public void regresar3(View v) {
        Intent intent = new Intent(Crear.this, Menu.class);
        Bundle b = new Bundle();
        b.putString("Nombre", username.getText().toString());
        Bundle bBueno = new Bundle();
        bBueno.putString("CU", cu.getText().toString());
        intent.putExtras(bBueno);
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);

    }
}
