package com.example.renatazavalad.proyecto;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Modificar extends AppCompatActivity {

    private EditText nuevo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modificar);

        nuevo = (EditText)findViewById(R.id.etNombreNuevo);
    }


    //este método modifica el  nombre del usuario de la tabla usuarios en la base de datos (nota: el nombre y el username
    //cosas diferentes)
    public void modificacion(View v){
        String nombre;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        nombre = nuevo.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("Nombre", nombre);
        int cant = bd.update("usuarios", registro, "Nombre= '"+ nombre + "'", null);
        bd.close();
        if(cant ==1)
            Toast.makeText(this, "Se modifico exitosamente", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "No se pudo modificar",Toast.LENGTH_LONG).show();

    }

    //Este método redirige a la clase perfil
    public void regresaPerfil(View v) {
        Intent intent = new Intent(Modificar.this, Perfil.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }
}
