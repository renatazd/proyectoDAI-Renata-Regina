package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MisLabs extends AppCompatActivity {

    private ListView labs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mislabs);

        labs = (ListView)findViewById(R.id.lvlabs);

        //Permite que se redirija a esta ventana
        Bundle bundle=this.getIntent().getExtras();
    }

    //Este método redirige al menú
    public void regresar6(View v) {
        Intent intent = new Intent(MisLabs.this, Menu.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //este método llena el listView y utiliza un adaptador de strings que usamos con un ArrayList de Strings
    public void gridLabs (View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        Bundle bundle = this.getIntent().getExtras();
        ArrayList<String> lista = new ArrayList<>();
        String bb = bundle.get("Nombre").toString();
        String query = "select materia from laboratorios where nombre = '" + bb + "'";
        Cursor fila = bd.rawQuery(query, null);
        String materias;
        try {
            if (fila != null) {
                while (fila.moveToNext()) {
                    materias = fila.getString(0);
                    lista.add(materias);
                }
                //utilizamos el adaptador para poder mostrar la informacion en el listview
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, lista);
                labs.setAdapter(dataAdapter);

            }
        }
        catch(IndexOutOfBoundsException e){
            Toast.makeText(this, "No se pudo", Toast.LENGTH_LONG).show();
        }
    }
}
