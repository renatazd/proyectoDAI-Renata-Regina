package com.example.renatazavalad.proyecto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class webView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web_view);


        //aqui se programa la funcionalidad del webview
        String url = "https://www.itam.mx";
        WebView wvWeb = (WebView)this.findViewById(R.id.wvWeb);
        wvWeb.getSettings().setJavaScriptEnabled(true);
        wvWeb.loadUrl(url);
    }
}
