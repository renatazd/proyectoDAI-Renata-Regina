package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {
    private Button btPerfil, btAgrega, btElimina,btLabs, btCerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        btPerfil=(Button)findViewById(R.id.btPerfil);
        btAgrega=(Button)findViewById(R.id.btAgrega);
        btElimina=(Button)findViewById(R.id.btElimina);
        btLabs=(Button)findViewById(R.id.btLabs);
        btCerrar=(Button)findViewById(R.id.btCerrar);

        //Permite que se pueda regresar al menú principal
        Bundle b1=this.getIntent().getExtras();
        Bundle b2=this.getIntent().getExtras();
    }

    //Este método redirige a la pantalla para ver el prfil del laboratorista
    // y realizar una modificación
    public void perfil(View v) {
        Intent intent = new Intent(Menu.this, Perfil.class);
        Bundle b1 = this.getIntent().getExtras();
        Bundle b2 = this.getIntent().getExtras();
        intent.putExtras(b1);
        intent.putExtras(b2);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige a la pantalla que permite crear un laboratorio
    public void crearLab(View v) {
        Intent intent = new Intent(Menu.this, AgregaLab.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige a la pantalla para ver los laboratorios que imparte el laboratorista
    public void laboratorios(View v) {
        Bundle bundle = this.getIntent().getExtras();
        Intent intent = new Intent(Menu.this, MisLabs.class);
        intent.putExtras(bundle);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige a la pantalla para eliminar un laboratorio
    public void eliminar(View v) {
        Intent intent = new Intent(Menu.this, Eliminar.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige a la pantalla de inicio de sesión
    public void cerrar(View v) {
        Intent intent = new Intent(Menu.this, IniciarSesion.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }


    //Este método redirige a la webview
    public void webv(View v) {
        Intent intent = new Intent(Menu.this, webView.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }


    }
