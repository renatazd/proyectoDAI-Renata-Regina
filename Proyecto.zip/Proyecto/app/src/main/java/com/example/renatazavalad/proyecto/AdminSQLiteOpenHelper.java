package com.example.renatazavalad.proyecto;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by renatazavalad on 18/12/17.
 */

public class AdminSQLiteOpenHelper extends SQLiteOpenHelper {



    //Constructor vacio de la clase para crear la database
    public AdminSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    //Oncreate donde creamos las tablas de la base
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table usuarios (cu integer primary key, nombre text, username text, password integer)");
        sqLiteDatabase.execSQL("create table laboratoriosUsuarios (username text references usuarios, nombre text references usuarios)");
        sqLiteDatabase.execSQL("create table laboratorios (folio integer primary key, nombre text,  materia text, horario integer, salon integer)");
    }

    @Override
    //onUpgrade donde se verifica la existencia de las tablas de la base de datos
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists usuarios");
        sqLiteDatabase.execSQL("create table usuarios (cu integer primary key, nombre text, username text, password integer)");
        sqLiteDatabase.execSQL("drop table if exists laboratorios");
        sqLiteDatabase.execSQL("create table laboratoriosUsuarios (username text references usuarios, nombre text references usuarios)");
        sqLiteDatabase.execSQL("drop table if exists laboratorios");
        sqLiteDatabase.execSQL("create table laboratorios (folio integer primary key, nombre text,  materia text, horario integer, salon integer)");
    }





}
