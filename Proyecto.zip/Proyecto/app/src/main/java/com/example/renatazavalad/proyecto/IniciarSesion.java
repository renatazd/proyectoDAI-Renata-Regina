package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class IniciarSesion extends AppCompatActivity {

    private Button botonCrea, botonInicia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iniciarsesion);

        botonCrea = (Button)findViewById(R.id.btIniciaSesion);
        botonInicia = (Button)findViewById(R.id.btCrearCuenta);

    }

    //Este método redirige al menú
    public void iniciar(View v){
        Intent intent = new Intent(IniciarSesion.this, UserNameActivity.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }

    //Este método redirige al menú
    public void crear(View v){
        Intent intent = new Intent(IniciarSesion.this, Crear.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        // de esta ventana de pasas a la siguiente, es como redirect
        startActivity(intent);
    }




}
