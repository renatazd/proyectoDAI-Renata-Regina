package com.example.renatazavalad.proyecto;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Eliminar extends AppCompatActivity {

    private EditText fol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eliminar);

        //Permite que se redirija a esta ventana
        Bundle bundle=this.getIntent().getExtras();

        fol = (EditText)findViewById(R.id.etFolioMat);
    }

    //Este método redirige al menú
    public void regresar7(View v) {
        Intent intent = new Intent(Eliminar.this, Menu.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }


    public void baja(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        int folio = Integer.parseInt(fol.getText().toString());
       // Toast.makeText(this, "hola", Toast.LENGTH_LONG).show();
        int cant = bd.delete("laboratorios", "folio="+ folio, null);
        bd.close();
        if(cant ==1)
            Toast.makeText(this, "Se borro el laboratorio", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "No se pudo eliminar el laboratorio",Toast.LENGTH_LONG).show();
    }
}
