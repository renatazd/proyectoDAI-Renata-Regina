package com.example.renatazavalad.proyecto;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AgregaLab extends AppCompatActivity {

    private EditText nombre, materiaLab, horario, salonLab, foli;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.agrega_lab);

        //Permite que otras ventanas se redirijan a estas
        Bundle bundle = this.getIntent().getExtras();


        nombre =(EditText) findViewById(R.id.etNomLaboratorista);
        materiaLab= (EditText) findViewById(R.id.etMateria);
        horario = (EditText) findViewById(R.id.etHorarioLaboratorio);
        salonLab = (EditText) findViewById(R.id.etSalon);
        foli = (EditText) findViewById(R.id.etFolio);
    }

    //limpia los campos de la vista
    public void limpiar(View v){
        nombre.setText("");
        materiaLab.setText("");
        horario.setText("");
        salonLab.setText("");
        foli.setText("");
    }

    //agrega un laboratorio nuevo a la cuenta del laboratorista por medio de la base de datos y las tablas
    public void altaLab(View v){
        String nom, materia, hora, salon, folio;
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null,1);
        //instanciamos la base de datos
        SQLiteDatabase bd = admin.getWritableDatabase();
        nom = nombre.getText().toString();
        materia = materiaLab.getText().toString();
        hora = horario.getText().toString();
        salon = salonLab.getText().toString();
        folio = foli.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("folio", folio);
        registro.put("materia", materia);
        registro.put("horario", hora);
        registro.put("nombre", nom);
        registro.put("salon", salon);
        long prueba = bd.insert("laboratorios", null, registro);
        limpiar(v);
        //verificamos que si se hayan insertado los datos a la base de datos
        if (prueba>0){
            Toast.makeText(this, "se cargaron los datos del laboratorio", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "No se cargaron los datos del laboratorio", Toast.LENGTH_LONG).show();
        }
        bd.close();
        limpiar(v);
    }

    //Este método redirige al menú
    public void regresar8(View v) {
        Intent intent = new Intent(AgregaLab.this, Menu.class);
        Bundle b = new Bundle();
        intent.putExtras(b);
        //de esta ventana te pasas a la siguiente, es como redirect
        startActivity(intent);
    }




}
